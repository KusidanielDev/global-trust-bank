import Link from "next/link";

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-white">
      {/* Hero */}
      <section className="bg-gradient-to-br from-blue-600 to-indigo-700 text-white">
        <div className="max-w-7xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">
              Banking that works for you.
            </h1>
            <p className="mt-4 text-blue-100 text-lg">
              Open an account in minutes. Track spending, transfer money, and grow your savings with smart insights.
            </p>
            <div className="mt-8 space-x-3">
              <Link href="/signup" className="px-5 py-3 rounded-lg bg-white text-blue-700 font-semibold shadow">
                Open account
              </Link>
              <Link href="/login" className="px-5 py-3 rounded-lg border border-white/70 font-semibold">
                Sign in
              </Link>
            </div>
            <p className="mt-4 text-sm text-blue-100">FDIC-insured up to $250,000. No monthly fees.</p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-2xl h-64 sm:h-80 shadow-inner" />
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-6 py-16">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Why GlobalTrust?</h2>
        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { title: "Instant transfers", desc: "Send and receive money in seconds—no hidden fees." },
            { title: "Powerful insights", desc: "Automatic categorization and budgets to help you save." },
            { title: "Top‑tier security", desc: "Multi‑factor auth, device protection, and encrypted data." },
            { title: "Global access", desc: "Use your account anywhere, anytime, on any device." },
            { title: "24/7 support", desc: "Real humans ready to help—day or night." },
            { title: "No monthly fees", desc: "Keep more of your money working for you." },
          ].map((f, i) => (
            <div key={i} className="p-5 bg-white border rounded-xl shadow-sm">
              <div className="text-lg font-semibold">{f.title}</div>
              <p className="mt-2 text-gray-600">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 py-14 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div>
            <h3 className="text-xl md:text-2xl font-bold text-gray-900">Ready to get started?</h3>
            <p className="text-gray-600">Join in minutes and take control of your money today.</p>
          </div>
          <div className="space-x-3">
            <Link href="/signup" className="px-5 py-3 rounded-lg bg-blue-600 text-white font-semibold shadow">
              Open account
            </Link>
            <Link href="/login" className="px-5 py-3 rounded-lg border border-blue-600 text-blue-600 font-semibold">
              Sign in
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
