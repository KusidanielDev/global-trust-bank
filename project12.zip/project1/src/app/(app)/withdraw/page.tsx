import { prisma } from "@/lib/db";
import { redirect } from "next/navigation";

async function withdraw(formData: FormData) {
  "use server";
  const accountId = String(formData.get("accountId"));
  const amount = parseFloat(String(formData.get("amount")));
  if (!accountId || !Number.isFinite(amount) || amount<=0) return;
  await prisma.transaction.create({
    data: {
      accountId,
      amount: -amount,
      date: new Date(),
      description: "Withdrawal",
      category: "Withdrawal",
    },
  });
  redirect(`/accounts/${accountId}`);
}

export default async function WithdrawPage() {
  const accounts = await prisma.account.findMany({ select: { id: true }});
  return (
    <div className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-4">Withdraw</h1>
      <form action={withdraw} className="space-y-4">
        <div>
          <label className="block text-sm font-medium">Account</label>
          <select name="accountId" className="mt-1 w-full border rounded p-2">
            {accounts.map(a => <option key={a.id} value={a.id}>Account {a.id.slice(0,6)}…</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium">Amount (USD)</label>
          <input name="amount" type="number" step="0.01" min="0.01" className="mt-1 w-full border rounded p-2" required />
        </div>
        <button className="w-full bg-black text-white rounded py-2">Withdraw</button>
      </form>
    </div>
  );
}
