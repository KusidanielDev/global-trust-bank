import { prisma } from "@/lib/db";
import { requireSession } from "@/lib/session";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { toCents } from "@/lib/money";

export const dynamic = "force-dynamic";

async function createAccount(formData: FormData) {
  "use server";
  const name = String(formData.get("name") || "").trim();
  const type = String(formData.get("type") || "").trim();
  const opening = toCents(Number(formData.get("opening") || 0));
  const { user } = await requireSession();
  const userId = (user as any)?.id as string;

  const acc = await prisma.account.create({
    data: {
      userId,
      name,
      type,
      balanceCents: opening,
      balance: opening / 100,
      accountNumber: Math.floor(
        1000000000 + Math.random() * 9000000000
      ).toString(),
    },
  });

  if (opening) {
    await prisma.transaction.create({
      data: {
        accountId: acc.id,
        description: "Opening deposit",
        amountCents: opening,
        amount: opening / 100,
        date: new Date(),
        category: "Deposit",
      },
    });
  }
  revalidatePath("/(app)/accounts");
  redirect(`/(app)/accounts/${acc.id}`);
}

export default async function NewAccountPage() {
  await requireSession();

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h1 className="text-2xl font-bold text-gray-900">
              Open a New Account
            </h1>
            <p className="text-gray-600">
              Get started with a new banking account in minutes
            </p>
          </div>

          <div className="p-6">
            <form action={createAccount} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Account Name
                  </label>
                  <input
                    name="name"
                    required
                    className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 shadow-sm"
                    placeholder="e.g. Everyday Checking"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Account Type
                  </label>
                  <select
                    name="type"
                    className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 shadow-sm"
                  >
                    <option>Checking</option>
                    <option>Savings</option>
                    <option>Money Market</option>
                    <option>Certificate of Deposit</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Opening Deposit
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">
                      $
                    </span>
                    <input
                      name="opening"
                      type="number"
                      min="0"
                      step="0.01"
                      className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 shadow-sm pl-8"
                      placeholder="0.00"
                    />
                  </div>
                  <p className="mt-1 text-xs text-gray-500">
                    Minimum $50 for most account types
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Funding Account
                  </label>
                  <select
                    name="funding"
                    className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 shadow-sm"
                  >
                    <option>Link External Account (Bank Transfer)</option>
                    <option>Cash Deposit</option>
                    <option>Check Deposit</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Account Features
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[
                    {
                      id: "debit-card",
                      label: "Debit Card",
                      defaultChecked: true,
                    },
                    {
                      id: "online-banking",
                      label: "Online Banking",
                      defaultChecked: true,
                    },
                    {
                      id: "mobile-app",
                      label: "Mobile App",
                      defaultChecked: true,
                    },
                    {
                      id: "paper-checks",
                      label: "Paper Checks",
                      defaultChecked: false,
                    },
                  ].map((feature) => (
                    <div
                      key={feature.id}
                      className="flex items-center bg-gray-50 p-3 rounded-lg"
                    >
                      <input
                        id={feature.id}
                        name="features"
                        type="checkbox"
                        defaultChecked={feature.defaultChecked}
                        className="h-4 w-4 text-blue-600 rounded focus:ring-blue-500"
                      />
                      <label
                        htmlFor={feature.id}
                        className="ml-2 text-sm text-gray-700"
                      >
                        {feature.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-gray-200">
                <div className="flex flex-col sm:flex-row justify-between gap-4">
                  <Link
                    href="/(app)/accounts"
                    className="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors text-center"
                  >
                    Cancel
                  </Link>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-blue-600 to-blue-700 text-white font-medium hover:from-blue-700 hover:to-blue-800 transition-all shadow-md"
                  >
                    Open Account
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>

        <div className="mt-8 bg-gradient-to-r from-blue-800 to-blue-900 rounded-xl p-6 text-white">
          <div className="flex flex-col md:flex-row items-center">
            <div className="mb-6 md:mb-0 md:mr-6">
              <div className="bg-blue-600 p-3 rounded-full w-12 h-12 flex items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                  />
                </svg>
              </div>
            </div>
            <div className="text-center md:text-left">
              <h3 className="text-xl font-bold mb-2">Security Guarantee</h3>
              <p className="text-blue-200">
                Your new account is protected by bank-level security and FDIC
                insurance up to $250,000. All transactions are monitored 24/7
                for suspicious activity.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
