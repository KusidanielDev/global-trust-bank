import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireSession } from "@/lib/session";
import { fmtUSD, getBalCents, getTxnCents } from "@/lib/money";
import { SpendingPie, CashflowArea } from "@/components/Charts";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const { user } = await requireSession();
  const userId = (user as any)?.id as string;

  const [accounts, recent, userData] = await Promise.all([
    prisma.account.findMany({
      where: { userId },
      orderBy: { updatedAt: "desc" },
    }),
    prisma.transaction.findMany({
      where: { account: { userId } },
      include: { account: true },
      orderBy: { date: "desc" },
      take: 120,
    }),
    prisma.user.findUnique({ where: { id: userId } }),
  ]);

  const total = accounts.reduce((s, a) => s + getBalCents(a), 0);
  const checking = accounts.filter((a) =>
    (a?.type || "").toLowerCase().includes("check")
  );
  const savings = accounts.filter((a) =>
    (a?.type || "").toLowerCase().includes("sav")
  );
  const credit = accounts.filter((a) =>
    (a?.type || "").toLowerCase().includes("credit")
  );
  const checkingTotal = checking.reduce((s, a) => s + getBalCents(a), 0);
  const savingsTotal = savings.reduce((s, a) => s + getBalCents(a), 0);
  const creditTotal = credit.reduce((s, a) => s + getBalCents(a), 0);

  const byCat = new Map<string, number>();
  for (const t of recent) {
    const k = (t as any)?.category || "Other";
    byCat.set(k, (byCat.get(k) ?? 0) + Math.abs(getTxnCents(t)));
  }
  const spendingPie = Array.from(byCat.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([name, value]) => ({ name, value }));
  const monthlySpend = Array.from(byCat.values()).reduce((s, v) => s + v, 0);
  const monthlyIncome = recent
    .filter((t) => getTxnCents(t) > 0)
    .reduce((s, t) => s + getTxnCents(t), 0);

  const daily = new Map<string, number>();
  for (const t of recent) {
    const d = new Date(t.date).toISOString().slice(0, 10);
    daily.set(d, (daily.get(d) ?? 0) + getTxnCents(t));
  }
  const days = Array.from(daily.keys()).sort();
  let running = 0;
  const cashflowArea = days.map((d) => {
    running += daily.get(d) ?? 0;
    return { name: d.slice(5), value: running / 100 };
  });

  // Get last 5 transactions for quick view
  const lastTransactions = recent.slice(0, 5);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      {/* <header className="bg-gradient-to-r from-blue-800 to-blue-900 text-white shadow-lg">
        <div className="container mx-auto px-4 py-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="bg-blue-600 p-2 rounded-lg">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3"
                  />
                </svg>
              </div>
              <h1 className="text-xl font-bold">GlobalBank</h1>
            </div>
            <div className="hidden md:flex space-x-6">
              {[
                "Dashboard",
                "Accounts",
                "Transfer",
                "Deposit",
                "Withdraw",
                "Loans",
              ].map((item) => (
                <Link
                  key={item}
                  href="#"
                  className={`font-medium hover:text-blue-200 transition-colors ${
                    item === "Dashboard"
                      ? "text-blue-300 border-b-2 border-blue-300"
                      : ""
                  }`}
                >
                  {item}
                </Link>
              ))}
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium">
                  {userData?.name || "User"}
                </p>
                <p className="text-xs text-blue-200">Premium Client</p>
              </div>
              <div className="bg-blue-600 w-10 h-10 rounded-full flex items-center justify-center">
                <span className="font-medium">
                  {userData?.name?.charAt(0) || "U"}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header> */}

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          {/* Welcome Section */}
          <section className="flex flex-col gap-2">
            <h1 className="text-2xl font-bold text-gray-800">
              Welcome back, {userData?.name?.split(" ")[0] || "User"}
            </h1>
            <p className="text-gray-600">
              Here's your financial overview as of{" "}
              {new Date().toLocaleDateString("en-US", {
                month: "long",
                day: "numeric",
                year: "numeric",
              })}
            </p>
          </section>

          {/* Main KPIs */}
          <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <KPI
              label="Total Balance"
              value={fmtUSD(total)}
              icon={
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-blue-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              }
              trend="up"
              hint="+2.5% from last month"
            />
            <KPI
              label="Checking"
              value={fmtUSD(checkingTotal)}
              icon={
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-blue-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                  />
                </svg>
              }
              hint={`${checking.length} account(s)`}
            />
            <KPI
              label="Savings"
              value={fmtUSD(savingsTotal)}
              icon={
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-blue-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"
                  />
                </svg>
              }
              hint={`${savings.length} account(s)`}
            />
            <KPI
              label="Monthly Spend"
              value={fmtUSD(monthlySpend)}
              icon={
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-blue-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              }
              trend="down"
              hint="-1.2% from last month"
            />
          </section>

          {/* Quick Actions */}
          <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { href: "/(app)/transfer", label: "Transfer Money", icon: "⇄" },
              { href: "/(app)/deposit", label: "Deposit Check", icon: "⮋" },
              { href: "/(app)/accounts/new", label: "Open Account", icon: "+" },
              {
                href: "/(app)/search",
                label: "Search Transactions",
                icon: "🔍",
              },
            ].map((a) => (
              <Link
                key={a.href}
                href={a.href}
                className="group card p-4 flex items-center justify-between bg-white rounded-xl shadow-sm hover:shadow-lg transition-all active:scale-[.98] border border-gray-100"
              >
                <div className="flex items-center space-x-3">
                  <div className="bg-blue-50 p-2 rounded-lg text-blue-600 group-hover:bg-blue-100 transition-colors">
                    <span className="text-lg">{a.icon}</span>
                  </div>
                  <span className="font-medium text-gray-800 group-hover:text-blue-700">
                    {a.label}
                  </span>
                </div>
                <span className="text-blue-600 group-hover:translate-x-0.5 transition-transform">
                  →
                </span>
              </Link>
            ))}
          </section>

          {/* Charts Section */}
          <section className="grid gap-6 lg:grid-cols-3">
            <div className="card p-5 bg-white rounded-xl shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">
                  Spending by Category
                </h3>
                <Link
                  href="/(app)/search"
                  className="text-sm text-blue-600 hover:underline"
                >
                  View Details
                </Link>
              </div>
              <div className="mt-4 h-64">
                {spendingPie.length ? (
                  <SpendingPie data={spendingPie} />
                ) : (
                  <EmptyChart />
                )}
              </div>
            </div>
            <div className="card p-5 bg-white rounded-xl shadow-sm lg:col-span-2">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">
                  Cash Flow (Last 60 Days)
                </h3>
                <div className="flex gap-2">
                  <Link
                    href="/(app)/accounts"
                    className="text-sm text-blue-600 hover:underline"
                  >
                    Export
                  </Link>
                  <Link
                    href="/(app)/search"
                    className="text-sm text-blue-600 hover:underline"
                  >
                    Details
                  </Link>
                </div>
              </div>
              <div className="mt-4 h-64">
                {cashflowArea.length ? (
                  <CashflowArea data={cashflowArea} />
                ) : (
                  <EmptyChart />
                )}
              </div>
            </div>
          </section>

          {/* Accounts Summary */}
          <section className="card p-6 bg-white rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">Your Accounts</h3>
              <Link
                href="/(app)/accounts"
                className="text-sm text-blue-600 hover:underline"
              >
                Manage Accounts
              </Link>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {accounts.slice(0, 3).map((account) => (
                <div
                  key={account.id}
                  className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-100 rounded-xl hover:shadow-sm transition-all"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-gray-900">
                        {account.name}
                      </h4>
                      <p className="text-sm text-gray-600">
                        {account.type || "Account"}
                      </p>
                    </div>
                    <span className="text-xs px-2 py-1 bg-blue-200/50 text-blue-800 rounded-full">
                      •••• {account.accountNumber?.slice(-4) || "1234"}
                    </span>
                  </div>
                  <div className="mt-4 flex justify-between items-end">
                    <p className="text-2xl font-bold text-gray-900">
                      {fmtUSD(getBalCents(account))}
                    </p>
                    <div className="text-xs px-2 py-1 bg-white text-blue-600 rounded">
                      {account.accountNumber?.startsWith("CHK")
                        ? "Active"
                        : "Active"}
                    </div>
                  </div>
                </div>
              ))}

              {accounts.length > 3 && (
                <Link
                  href="/(app)/accounts"
                  className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-blue-200 rounded-xl hover:border-blue-300 hover:bg-blue-50 transition-colors"
                >
                  <div className="text-2xl font-bold text-blue-500">+</div>
                  <p className="mt-2 text-sm font-medium text-blue-600">
                    View all accounts
                  </p>
                  <p className="text-xs text-gray-500">
                    {accounts.length} accounts total
                  </p>
                </Link>
              )}
            </div>
          </section>

          {/* Recent Transactions */}
          <section className="card p-6 bg-white rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">
                Recent Transactions
              </h3>
              <Link
                href="/(app)/search"
                className="text-sm text-blue-600 hover:underline"
              >
                View All
              </Link>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Date
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Description
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Account
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Amount
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {lastTransactions.map((txn) => (
                    <tr
                      key={txn.id}
                      className="hover:bg-blue-50 transition-colors"
                    >
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(txn.date).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                        })}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {txn.description || "Transaction"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {txn.account?.name || "Account"} ••••
                        {txn.account?.accountNumber?.slice(-4) || "1234"}
                      </td>
                      <td
                        className={`px-6 py-4 whitespace-nowrap text-sm font-medium ${
                          getTxnCents(txn) > 0
                            ? "text-green-600"
                            : "text-gray-900"
                        }`}
                      >
                        {getTxnCents(txn) > 0 ? "+" : ""}
                        {fmtUSD(getTxnCents(txn))}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

function KPI({
  label,
  value,
  hint,
  icon,
  trend,
}: {
  label: string;
  value: string;
  hint?: string;
  icon?: React.ReactNode;
  trend?: "up" | "down";
}) {
  return (
    <div className="card p-5 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow border border-gray-100">
      <div className="flex justify-between items-start">
        <div>
          <div className="text-sm font-medium text-gray-600">{label}</div>
          <div className="mt-2 text-2xl font-bold text-gray-900">{value}</div>
          {hint && <div className="mt-1 text-xs text-gray-500">{hint}</div>}
        </div>
        {icon && (
          <div className="bg-blue-100 p-2 rounded-lg text-blue-600">{icon}</div>
        )}
      </div>
      {trend && (
        <div
          className={`mt-3 flex items-center text-xs font-medium ${
            trend === "up" ? "text-green-600" : "text-red-600"
          }`}
        >
          {trend === "up" ? "▲" : "▼"}
          <span className="ml-1">
            {trend === "up" ? "Increased" : "Decreased"}
          </span>
        </div>
      )}
    </div>
  );
}

function EmptyChart() {
  return (
    <div className="h-40 w-full rounded-lg bg-gray-50 border border-dashed border-gray-200 grid place-items-center text-sm text-gray-500">
      No data available
    </div>
  );
}
